# Ariljaach University Landing Page

Maru.mn шиг motion хөдөлгөөнтэй, logo-ийн өнгө (ногоон-цэнхэр-алтан gradient) ашигласан орчин үеийн Landing Page.

## 🎨 Онцлог

### ✅ Хэрэгжсэн функцүүд

1. **Branding - Ariljaach University**
   - Лого оруулсан (navbar болон footer)
   - Лого-ийн өнгө (ногоон-цэнхэр-шар gradient) ашигласан дизайн
   - **8 жилийн туршлага** - Үнэн зөв мэдээлэл
   - **100% төлбөр буцаалт баталгаа**

2. **Video Танилцуулга Хэсэг**
   - YouTube video embed
   - Skool community-тэй танилцуулга
   - Хэрхэн нэгдэх талаар дэлгэрэнгүй
   - Responsive video player (16:9 aspect ratio)

3. **Skool Community Нэгдэх Заавар**
   - 4 үндсэн шаардлага:
     1. Бүрэн Танилцуулга Үзэх
     2. Skool Бүртгэл Үүсгэх
     3. Нийгэмлэгийн Дүрэм Зөвшөөрөх
     4. Идэвхтэй Оролцоо
   - Community card with stats (500+ гишүүд, 50+ хичээлүүд)
   - Онцлогууд жагсаалт

4. **Motion эффектүүд**
   - Parallax scrolling (gradient orbs - лого өнгөөр)
   - Fade-in animations (scroll-triggered)
   - Hover effects (3D transforms)
   - Smooth transitions
   - Scroll progress indicator
   - Interactive floating cards

5. **Дизайн (Logo-ийн өнгөөр)**
   - Primary: `#2d5f4f → #4a9d7f → #d4af37` (Ногоон → Цэнхэр ногоон → Алтан)
   - Gradient background orbs
   - Responsive навигаци
   - CTA товчнууд
   - Feature cards with 3D hover

## 🎯 Хуудасны бүтэц

```
/
├── index.html              (Main landing page)
├── css/
│   ├── style.css          (Base styles with logo colors)
│   └── additions.css      (New sections: video, community)
├── js/
│   └── main.js            (Interactive functionality)
└── README.md
```

## 🔗 URL Endpoints

- **/** - Main landing page
- **/#home** - Hero section (8 жилийн туршлага, 100% төлбөр буцаалт)
- **/#video** - Video танилцуулга
- **/#community** - Skool community заавар
- **/#features** - Features section
- **/#results** - Testimonials
- **/#contact** - Footer

## 🚀 Технологи

- **HTML5** - Semantic markup
- **CSS3** - Custom animations, gradients, logo-based colors
- **JavaScript (Vanilla)** - Interactive effects, scroll animations
- **Font Awesome** - Icons
- **Google Fonts (Inter)** - Typography
- **YouTube Embed API** - Video player

## 🎨 Өнгөний схем (Logo-оос авсан)

- Primary: `#3a8f6f` (Forest Green)
- Secondary: `#2d5f4f` (Deep Green)
- Accent: `#4a9d7f` (Teal)
- Success: `#5ab88f` (Light Green)
- Gold Accent: `#d4af37` (Golden Yellow)

## 📱 Responsive Design

- Desktop (1200px+) - Бүх эффектүүд
- Tablet (768px - 1199px) - Optimized layout
- Mobile (< 768px) - Hamburger menu, stacked content

## 📊 Статистик мэдээлэл

- **50+ Амжилттай трейдер**
- **8+ Жилийн туршлага** (UK, US-ын багш нараас суралцсан)
- **100% Төлбөр буцаалт** (6 сарын дотор ашигтай болохгүй бол)

## 🎬 Шинэ Хэсгүүд

### Video Section
- YouTube video embed with responsive container
- 16:9 aspect ratio maintained
- Shadow effects for depth
- Smooth loading animation

### Community Section
- Requirements list with 4 steps
- Interactive hover effects on requirement cards
- Community showcase card with:
  - Member count (500+)
  - Course count (50+)
  - Free content (100%)
  - Feature highlights (XWave, Psychology, Live хичээлүүд, Нийгэмлэгийн дэмжлэг)

### Features Section
- 6 feature cards with icons
- 3D hover tilt effects
- Gradient icons matching logo colors
- Responsive grid layout

### Results/Testimonials
- 3 student success stories
- ROI percentages (+180%, +145%, +220%)
- Interactive zoom-in animations

## 📋 Устгасан хэсгүүд

- **Program Timeline Section** - HTML-д comment хэлбэрээр хадгалсан (<!-- -->), шаардлагатай үед сэргээж болно

## 🔮 Дараагийн алхмууд

1. **YouTube Video URL солих**
   - Одоогийн placeholder URL (`dQw4w9WgXcQ`) солих
   - Жинхэнэ танилцуулга видео оруулах
   - `index.html` line ~155 дээр солино

2. **Skool Community Link оруулах**
   - CTA товчнуудад жинхэнэ холбоос оруулах
   - "Skool-д нэгдэх" button функционал

3. **Form Integration**
   - Email бүртгэл form
   - Холбоо барих form with validation

4. **Analytics & Tracking**
   - Google Analytics integration
   - Conversion tracking
   - Heatmap analysis

5. **Backend Services**
   - Skool API integration (if available)
   - User enrollment tracking
   - Email automation

6. **Content Updates**
   - Real testimonials with photos
   - Actual course screenshots
   - Live trading results

## 🚀 Deployment

Вэбсайтыг deploy хийхийн тулд **Publish tab** руу очоод нэг товчлуурын дарцаар шууд deploy хийнэ үү!

## 📝 Анхааруулга

- Video URL нь placeholder (`dQw4w9WgXcQ`), жинхэнэ танилцуулга видеогоо оруулна уу
- Skool community холбоосыг бодит холбоосоор солино уу
- Email хаяг (`info@ariljaach.mn`) шалгаж, жинхэнэ хаягаар солино уу
- Testimonial-ууд placeholder text - жинхэнэ сурагчдын үгээр солино

## 🎨 Дизайн онцлог

- Logo-ийн өнгийг бүх gradient elements дээр ашигласан
- Motion эффектүүд: Maru.mn style parallax scrolling
- Smooth scroll animations
- 3D card hover effects
- Responsive video embed
- Interactive requirement cards

---

**Created with 🌱 for Ariljaach University - 8 жилийн туршлагатай багштай хамт**